public class Main { 
    public static void main(String[] args) { 
        int grades = 91; 
        
        if(grades >= 90 && grades <= 100) { 
            System.out.println("good"); 
        } else if (grades >= 80 && grades <= 89) { 
            System.out.println("not bad"); 
        } else { 
            System.out.println("failed"); 
        } 
    } 
}
