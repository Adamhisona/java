import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String username, password;
		
		while (true){
		System.out.print("Enter Username: ");
		username = input.nextLine();
		System.out.print("Enter Password ");
		password = input.nextLine();
		
		if(username.equals("admin") && password.equals("admin")){
			
			System.out.println("Login Success");
			break;
		}else {
		System.out.println("Login Failed");
		}
		}
	}
}