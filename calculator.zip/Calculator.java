public class Calculator { 
    public static void main(String[] args) { 
        int num1 = 20; 
        int num2 = 30; 

        System.out.println("1st number: " + num1); 
        System.out.println("2nd number: " + num2); 
        System.out.println(""); 

        int sum = num1 + num2; 
        System.out.println("Sum: " + sum); 

        int difference = num1 - num2; 
        System.out.println("Difference: " + difference); 

        int product = num1 * num2; 
        System.out.println("Product: " + product); 

        double quotient = (double)num1 / num2; 
        int remainder = num1 % num2; 
        System.out.println("Quotient: " + quotient); 
        System.out.println("Remainder: " + remainder); 
    } 
}