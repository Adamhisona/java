
public class Formatting {

    
    public static void main(String[] args) {
        
        String collage= "BCP";
        String name= "Adam hisona";
        // %s is for string 
        System.out.printf(" college: %s \n name: %s", collage,name);
        System.out.printf("\n formatting via width: %.4s \n",name);
        // %d is for integer
        int grade=100;
        System.out.printf("\n Your grade: %d", grade);
        //  always put f on the end of the float
        //  float or double for cecimals
        float number= 10.562798635986539861f;
        System.out.printf("\n your avarage: %f\n",number); 
        //formating using width
        System.out.printf(" formatting via width: %.4f \n",number);
        // display using precision/round off//
        System.out.printf("formatting via precision: %.3f",number);
    }
    
}
